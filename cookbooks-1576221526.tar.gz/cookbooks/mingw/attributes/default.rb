# override these attributes to pull the msys2 package from a custom url
default['msys2']['url'] = 'http://downloads.sourceforge.net/project/msys2/Base/x86_64/msys2-base-x86_64-20160205.tar.xz'
default['msys2']['checksum'] = '7e97e2af042e1b6f62cf0298fe84839014ef3d4a3e7825cffc6931c66cc0fc20'
